  <div id="footer">
    <div class="container_16">
      <?php do_action( 'prana_footer' ); ?>
    </div>
  </div>

</div> <!-- end .wrapper -->
<?php wp_footer(); ?>
</body>
</html>